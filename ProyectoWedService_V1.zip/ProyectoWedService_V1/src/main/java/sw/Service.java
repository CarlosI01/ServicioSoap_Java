/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sw;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author 59399
 */
@WebService(serviceName = "Service")
public class Service {

    /**
     * This is a sample web service operation
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }
     @WebMethod(operationName = "Login")
    public Boolean Login(@WebParam(name = "Usuario") String usuario, @WebParam(name = "Password") String password) {

        if (usuario.equals("CarlosTH") && password.equals("12345")) {
            return true;
        } else {
            return false;
        }
    }

   @WebMethod(operationName = "Procesar_Pagos")
    public int Procesar_Pagos(@WebParam(name = "pago") int pago, @WebParam(name = "total_pagar") int total_pagar) {
        if (pago >= total_pagar) {
            return pago - total_pagar;
        } else {
            return -1;
        }
        
    }
}
